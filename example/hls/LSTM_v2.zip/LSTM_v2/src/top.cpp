#include <iostream>
#include <math.h>
#include "top.h"
using namespace std;


/*
 * @note: the top function for synthesis
 */
void Neural(float *sample, unsigned int *result, int N)
{
	/* define the interface */
#pragma HLS INTERFACE axis port=sample depth=784000
#pragma HLS INTERFACE axis port=result depth=784000
#pragma HLS INTERFACE s_axilite port=N
#pragma HLS INTERFACE s_axilite port=return

	/* the array for input */
	TYPE_T data[INPUT_LENGTH][INPUT_DIM];

	/* declare a Gated Recurrent Neural Network */
	LSTM<INPUT_LENGTH, INPUT_DIM, OUTPUT_DIM, TANH, SIGMOID>				lstm_nn(weight_i, weight_c, weight_f, weight_o);

	/* add a dense layer for classification */
	Dense<OUTPUT_DIM, NB_CLASS, SOFTMAX>									dense(dense_weight);


	for (int k = 0; k < N; k++)
	{
#pragma HLS LOOP_TRIPCOUNT min=1 max=1000

		/* generate the test vector */
		for (int i = 0; i < INPUT_LENGTH; i++)
		{
			for( int j = 0; j < INPUT_DIM; j++)
			{
#pragma HLS pipeline
				data[i][j] = sample[i*INPUT_DIM + j + k*INPUT_DIM*INPUT_LENGTH];
			}
		}

		/* the lstm layer process */
		lstm_nn.feedforward(data);

		/* the fully connected layer process*/
		dense.feedforward(lstm_nn.res);

		/* output the result */
		result[k] = utils_find_category<NB_CLASS>(dense.res);
	}

}
