#include <iostream>
#include "top.h"
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <assert.h>
using namespace std;


int main()
{
	const int N = 480;
//	const int N = 100;
	float	sample[N*IN_SIZE];
	unsigned int result[N] = {0};
	unsigned int std_result[N] = {0};

	/* load the standard sample category */
	FILE *fp = fopen("result.txt", "r");
	if( !fp)
	{
		cout << " Failed to open result.txt " << endl;
	}
	int i = 0;
	while( fscanf(fp, "%d", &std_result[i]) && i < N)
	{
		i++;
	}
	fclose(fp);

	/* load the MNIST sample */
	fp = fopen("validation.txt", "r");
	if( !fp)
	{
		cout << " Failed to open result.txt " << endl;
	}
	for( int i = 0; i < N; i++)
	{
		for(int j = 0; j < IN_SIZE; j++)
			fscanf(fp, "%f", &sample[i*IN_SIZE + j]);
	}
	fclose(fp);

	for( int i = 0; i < N * IN_SIZE; i++ )
	{
		sample[i] *= 100;
	}


	/* the main process */
#if 0
	int index = 10;
	Neural(sample2, result, 1);
#else
	Neural(sample, result, N);
#endif

#if 1
	/* compare the result */
	int  n_wrong = 0;
	for( int i = 0; i < N; i++)
	{
		if( result[i] != std_result[i])
		{
			n_wrong++;
			cout << i << " th failed," << result[i] << " " << std_result[i] << endl;
		}
	}
	float rate = float(N - n_wrong)/float(N);
	cout << n_wrong << " wrong in " << N << "samples with accuracy of " << rate << endl;
#endif
	return 0;

}


