#include <iostream>
#include <math.h>
#include <stdio.h>
#include "top.h"
using namespace std;


/*
 * @note: the top function for synthesis
 */
unsigned int Neural(volatile float *conv1_in, volatile float *conv1_out, volatile float *pool1_out, volatile float *conv2_out, volatile float *pool2_out,
		volatile float *dense_weight)
{
	/* define the interface */
#pragma HLS INTERFACE m_axi port=conv1_in depth=1024 offset=slave
#pragma HLS INTERFACE m_axi port=conv1_out depth=1024 offset=slave
#pragma HLS INTERFACE m_axi port=pool1_out depth=1024 offset=slave
#pragma HLS INTERFACE m_axi port=conv2_out depth=1024 offset=slave
#pragma HLS INTERFACE m_axi port=pool2_out depth=1024 offset=slave
#pragma HLS INTERFACE m_axi port=dense_weight depth=10240 offset=slave
#pragma HLS INTERFACE s_axilite port=return

	/* define the first Convolution2D layer */
	Convolution2D_DataStream<NB_FILTER1, NB_ROW, NB_COL, ROW, COL, INPUT_DIM, RELU, SUBSAMPLE_ROW, SUBSAMPLE_ROW>		conv1(weight1, bias1);

	/* define the first MaxPooling2D layer */
	MaxPooling2D_Stream<POOLING1_ROW, POOLING1_COL, NB_FILTER1, POOLING_ROW, POOLING_COL>								pool1;

	/* define the second Convolution2D layer */
	Convolution2D_DataStream<NB_FILTER2, NB_ROW, NB_COL, ROW2, COL2, INPUT_DIM2, RELU, SUBSAMPLE_ROW, SUBSAMPLE_ROW>	conv2(weight2, bias2);

	/* define the second MaxPooling2D layer */
	MaxPooling2D_Stream<POOLING2_ROW, POOLING2_COL, NB_FILTER2, POOLING_ROW, POOLING_COL>								pool2;

	/* convert the AXI stream to 1D array */
	Reshape_Stream_1D<DENSE_INPUT>																						reshape;

	/* define a Dense_WeightStream layer */
	Dense_WeightStream<DENSE_INPUT, DENSE_OUTPUT, RELU>																	dense;

	/* define the second Dense layer */
	Dense<DENSE_OUTPUT, DENSE2_OUTPUT, SOFTMAX>																			dense2(weight4);

	/* the first convolution and maxpooling layer  */
	conv1.feedforward(conv1_in, conv1_out);
	pool1.feedforward(conv1_out, pool1_out);

	/* the second convolution and maxpooling layer */
	conv2.feedforward( pool1_out, conv2_out );
	pool2.feedforward( conv2_out, pool2_out );

	/* convert the AXI stream to 1D array */
	reshape.feedforward(pool2_out);

	/* the fully connected layer */
	dense.feedforward(dense_weight, reshape.res);

	/* the classification layer */
	dense2.feedforward(dense.res);

	/* find the classified catagory */
	TYPE_PINT res = utils_find_category<DENSE2_OUTPUT>(dense2.res);

	/* output the result */
	 return res;
}
