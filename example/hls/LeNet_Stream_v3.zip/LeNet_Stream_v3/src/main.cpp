#include <iostream>
#include "top.h"
#include <math.h>
#include <time.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
using namespace std;


int main()
{
	const int N = 480;
//	const int N = 10;
	/* load the data from the text file */
	unsigned int std_result[N];
	unsigned int result[N];
	float		 sample[N*ROW*COL];

	/* load the standard sample category */
	FILE *fp = fopen("result.txt", "r");
	if( !fp)
	{
		cout << " Failed to open result.txt " << endl;
	}
	int i = 0;
	while( fscanf(fp, "%d", &std_result[i]) && i < N)
	{
		i++;
	}
	fclose(fp);

	/* load the MNIST sample */
	fp = fopen("validation.txt", "r");
	if( !fp)
	{
		cout << " Failed to open result.txt " << endl;
	}
	for( int i = 0; i < N; i++)
	{
		for(int j = 0; j < ROW * COL; j++)
			fscanf(fp, "%f", &sample[i*ROW*COL + j]);
	}
	fclose(fp);

	/* get the transpose array for the Dense_WeightStream Layer */
	float dense_weight[(DENSE_INPUT+1) * DENSE_OUTPUT];
	for( int i = 0; i < DENSE_INPUT + 1; i++)
		for( int j = 0; j < DENSE_OUTPUT; j++)
			dense_weight[j*(DENSE_INPUT + 1) + i] = weight3[i*DENSE_OUTPUT + j];


	/* define the other arrays */
	float conv1_out[POOLING1_ROW * POOLING1_COL * NB_FILTER1];
	float pool1_out[ROW2 * COL2 * INPUT_DIM2];
	float conv2_out[POOLING2_ROW * POOLING2_COL * NB_FILTER2];
	float pool2_out[DENSE_INPUT];
	/* the main process */
	for( int i = 0; i < N; i++)
	{
		result[i] = Neural(&sample[i * ROW * COL], conv1_out, pool1_out, conv2_out, pool2_out, dense_weight);
	}

	/* compare the result */
	int  n_wrong = 0;
	for( int i = 0; i < N; i++)
	{
		if( result[i] != std_result[i])
		{
			n_wrong++;
			cout << i << " th failed," << result[i] << " " << std_result[i] << endl;
		}
	}
	float rate = float(N - n_wrong)/float(N);
	cout << n_wrong << " wrong in " << N << "samples with accuracy of " << rate << endl;
	return 0;
}


