#include <iostream>
#include <math.h>
#include <stdio.h>
#include "top.h"
using namespace std;


/*
 * @note: the top function for synthesis
 */
void Neural(float *sample, unsigned int *result, int N)
{
	/* define the interface */
#pragma HLS INTERFACE axis port=sample
#pragma HLS INTERFACE axis port=result
#pragma HLS INTERFACE s_axilite port=N
#pragma HLS INTERFACE s_axilite port=return

	/* the array for input */
	TYPE_T data[ROW][COL][INPUT_DIM];

	/* define the first Convolution2D layer */
	Convolution2D<NB_FILTER1, NB_ROW, NB_COL, ROW, COL, INPUT_DIM, RELU, SUBSAMPLE_ROW, SUBSAMPLE_ROW>		conv1(weight1, bias1);

	/* define the first MaxPooling2D layer */
	MaxPooling2D<POOLING1_ROW, POOLING1_COL, NB_FILTER1, POOLING_ROW, POOLING_COL>							pool1;

	/* define the second Convolution2D layer */
	Convolution2D<NB_FILTER2, NB_ROW, NB_COL, ROW2, COL2, INPUT_DIM2, RELU, SUBSAMPLE_ROW, SUBSAMPLE_ROW>	conv2(weight2, bias2);

	/* define the second MaxPooling2D layer */
	MaxPooling2D<POOLING2_ROW, POOLING2_COL, NB_FILTER2, POOLING_ROW, POOLING_COL>							pool2;

	Reshape3D_1D<POOLING2_ROW/POOLING_ROW, POOLING2_COL/POOLING_COL, NB_FILTER2>							reshape;

	/* define the Dense layer */
	Dense<DENSE_INPUT, DENSE_OUTPUT, RELU>																	dense(weight3);

	/* define the second Dense layer */
	Dense<DENSE_OUTPUT, DENSE2_OUTPUT, SOFTMAX>																dense2(weight4);


	for (int k = 0; k < N; k++)
	{
#pragma HLS LOOP_TRIPCOUNT min=1 max=1000

		/* generate a test vector */
		for (int i = 0; i < ROW; i++)
		{
			for (int j = 0; j < COL; j++)
			{
				for( int v = 0; v < INPUT_DIM; v++)
				{
#pragma HLS pipeline
					data[i][j][v] = sample[i*COL*INPUT_DIM + j*INPUT_DIM + v + k*ROW*COL];
				}
			}
		}
		/* the process */
		conv1.feedforward(data);
		pool1.feedforward(conv1.res);

		conv2.feedforward(pool1.res);
		pool2.feedforward(conv2.res);

		reshape.feedforward(pool2.res);

		dense.feedforward(reshape.res);
		dense2.feedforward(dense.res);

		/* find the classified catagory */
		TYPE_PINT res = utils_find_category<DENSE2_OUTPUT>( dense2.res );

		/* output the result */
		result[k] = res;
	}

}
