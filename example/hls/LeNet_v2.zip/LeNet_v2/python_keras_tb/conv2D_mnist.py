'''Trains a simple convnet on the MNIST dataset.

Gets to 99.25% test accuracy after 12 epochs
(there is still a lot of margin for parameter tuning).
16 seconds per epoch on a GRID K520 GPU.
'''

import numpy as np
np.random.seed(1337)  # for reproducibility

from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation, Flatten
from keras.layers import Convolution2D, MaxPooling2D, MaxPooling1D
from keras.utils import np_utils
from keras import backend as K
import mnist_loader
import string

TRAIN_N = 50000
TEST_N = 10000

batch_size = 128
nb_classes = 10
nb_epoch = 60

# input image dimensions
img_rows, img_cols = 28, 28
# number of convolution2D filters to use
nb_filters1 = 3
nb_filters2 = 6
# size of pooling area for max pooling
pool1_size = (2, 2)
pool2_size = (2, 2)
# convolution kernel size
kernel_size = (3, 3)
#the dense size
dense_size = 32

#enable print big numpy array
np.set_printoptions(precision=8, threshold='nan')


# the data, shuffled and split between train and test sets
(X_train, y_train), (X_test, y_test), (X_validation, y_validation) = mnist_loader.load_data()

if K.image_dim_ordering() == 'th':
    X_train = X_train.reshape(X_train.shape[0], 1, img_rows, img_cols)
    X_test = X_test.reshape(X_test.shape[0], 1, img_rows, img_cols)
    X_validation = X_validation.reshape(X_validation.shape[0], 1, img_rows, img_cols)
    input_shape = (1, img_rows, img_cols)
else:
    X_train = X_train.reshape(X_train.shape[0], img_rows, img_cols, 1)
    X_test = X_test.reshape(X_test.shape[0], img_rows, img_cols, 1)
    X_validation = X_validation.reshape(X_validation.shape[0], img_rows, img_cols, 1)
    input_shape = (img_rows, img_cols, 1)

X_train = X_train.astype('float32')
X_test = X_test.astype('float32')
X_validation = X_validation.astype('float32')

print('X_train shape:', X_train.shape)
print(X_train.shape[0], 'train samples')
print(X_test.shape[0], 'test samples')

# convert class vectors to binary class matrices
Y_train = np_utils.to_categorical(y_train, nb_classes)
Y_test = np_utils.to_categorical(y_test, nb_classes)
Y_validation = np_utils.to_categorical(y_validation, nb_classes)

##build the network
model = Sequential()
#the fist Convolution2D and MaxPooling2D
model.add(Convolution2D(nb_filters1, kernel_size[0], kernel_size[1], border_mode='valid', input_shape=input_shape))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=pool1_size))

model.add(Convolution2D(nb_filters2, kernel_size[0], kernel_size[1], border_mode='valid'))
model.add(Activation('relu'))
model.add(MaxPooling2D(pool_size=pool2_size))

#flatten the output
model.add(Flatten())

#the dense layer
model.add(Dense(dense_size))
model.add(Activation('relu'))
model.add(Dropout(0.5))

#the output layer
model.add(Dense(nb_classes))
model.add(Activation('softmax'))

##print the network information
model.summary()

# exit()

#train and evaluate the network
model.compile(loss='categorical_crossentropy',
              optimizer='adadelta',
              metrics=['accuracy'])

model.fit(X_train[:TRAIN_N], Y_train[:TRAIN_N], batch_size=batch_size, nb_epoch=nb_epoch,
          verbose=1, validation_data=(X_test[:TEST_N], Y_test[:TEST_N]))
score = model.evaluate(X_validation, Y_validation, verbose=0)
print('Test score:', score[0])
print('Test accuracy:', score[1])

print "----print and save layers information---------"
for layer in model.layers:
    print "----------------------------------"
    print layer.__class__
    w = layer.get_weights()
    print w



##get the predict and intermediate result
get_layer_output = [K.function([model.layers[0].input, K.learning_phase()], [model.layers[i].output]) for i in range(len(model.layers))]

print "-----------test vector-------------------------"
POS = 10
s = X_test[POS]
s = s.reshape(1, s.shape[0], s.shape[1], s.shape[2])
res = model.predict( s )
print "-----------test vector-------------------------"
print s
print "-----------test output-------------------------"
print Y_test[POS]
print res

for k, layer  in zip(range(len(get_layer_output)), model.layers):
    print "-------", layer.__class__,"---intermediate result-------"
    print get_layer_output[k]([s, 0])[0].shape
    result = get_layer_output[k]([s, 0])[0]
    print result
    result.tofile("output"+str(k)+str(layer.__class__), sep=' ', format='%s')

